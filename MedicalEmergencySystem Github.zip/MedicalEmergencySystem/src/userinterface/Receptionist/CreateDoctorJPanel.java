/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userinterface.Receptionist;

import Project.EcoSystem;
import Project.Employee.Employee;
import Project.Venture.Venture;
import Project.MedicalEmployment.DoctorService;
import Project.MedicalEmployment.DoctorrList;
import Project.MedicalEmployment.PatienttList;
import Project.Network.NetworkService;
import Project.Organization.DoctorOrganizationService;
import Project.Organization.OrganizationService;
import Project.Organization.PatientOrganizationService;
import Project.Role.DoctorRoleService;
import Project.Role.EmergencyDoctorRoleService;
import Project.Role.PatientRoleService;
import Project.UserAccount.UserAccountService;
import java.awt.CardLayout;
import java.awt.Component;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Dell
 */

    

public class CreateDoctorJPanel extends javax.swing.JPanel {

    /**
     * Creates new form CreateDoctorJPanel
     */
    JPanel userProcessContainer;
    EcoSystem ecoSystem;
    DoctorrList  doctorList;
    NetworkService network;
    DoctorService doctor;
    public CreateDoctorJPanel(JPanel userProcessContainer, EcoSystem ecoSystem, DoctorrList doctorList, 
            NetworkService network) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.ecoSystem  = ecoSystem;
        this.doctorList = doctorList;
        this.network = network   ;     
        //jbtnUpdate.setVisible(false);
    }
    
    public CreateDoctorJPanel(JPanel userProcessContainer, EcoSystem ecoSystem, DoctorrList doctorList, 
            NetworkService network,DoctorService doctor) {
        initComponents();
        this.userProcessContainer = userProcessContainer;
        this.ecoSystem  = ecoSystem;
        this.doctorList = doctorList;
        this.network = network   ;   
        this.doctor= doctor;
        jLabel1.setText("Update Doctor");
        populatefield();
        txtDoctorName.setEditable(false);      
        txtName.setEditable(false);
        txtPasswd.setEditable(false);
        jbtnCreate.setVisible(false);
                          
    }

    public void populatefield()
    {
         txtDoctorName.setText(doctor.getDoctorName());
      txtQuali.setText(doctor.getDocQualification());
        txtSpeci.setText(doctor.getSpecilizationnName());
        
    
        chkboxEmeDoctor.setSelected(doctor.getEmergencyDoctorr());
          OrganizationService doctorOrg = null;
        for(Venture enterprise : network.getVentureDirectory().getVentureList())
        {
            for (OrganizationService organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
               if (organization instanceof DoctorOrganizationService ) {

                   doctorOrg = organization;
                   break;
               }
           }
        }
                String UserName = "" ;
                String Password = ""; 
            for(DoctorService doctor : doctorList.getDoctorrList())
            {
                
                for(UserAccountService useraccount : doctorOrg.getUserAccounttDirectory().getUserAccounttList())
                {
                    if(useraccount.getEmployeee().getName().equals(doctor.getDoctorName()))
                    {
                        UserName = useraccount.getUserName();
                        Password = useraccount.getUserName();
                    }
                }
            }
              txtName.setText(UserName);
                txtPasswd.setText(Password);
            
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtDoctorName = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtQuali = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtSpeci = new javax.swing.JTextField();
        jbtnCreate = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jkButton2 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        chkboxEmeDoctor = new javax.swing.JCheckBox();
        jLabel8 = new javax.swing.JLabel();
        txtPasswd = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CREATE DOCTOR");
        jLabel1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(259, 26, 194, 39));

        jLabel2.setText("Doctor Name :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(198, 214, 95, -1));
        jPanel1.add(txtDoctorName, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 209, 209, -1));

        jLabel3.setText("Qualification :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(204, 275, -1, -1));
        jPanel1.add(txtQuali, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 265, 209, -1));

        jLabel4.setText("Specilization in :");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(189, 326, -1, -1));
        jPanel1.add(txtSpeci, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 321, 209, -1));

        jbtnCreate.setText("Create ");
        jbtnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCreateActionPerformed(evt);
            }
        });
        jPanel1.add(jbtnCreate, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 430, 87, -1));

        jLabel5.setText("User Name :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(217, 100, -1, -1));
        jPanel1.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 95, 209, -1));

        jLabel6.setText("Password :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(226, 158, -1, -1));

        jkButton2.setText("<< Back");
        jkButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jkButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jkButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 430, 100, -1));

        jLabel7.setText("Emergency Doctor :");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 377, -1, -1));
        jPanel1.add(chkboxEmeDoctor, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 377, 209, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Business/Images/folder/doctor-clinic-illustration_1270-69.jpg"))); // NOI18N
        jLabel8.setText("jLabel8");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 6, 134, 117));
        jPanel1.add(txtPasswd, new org.netbeans.lib.awtextra.AbsoluteConstraints(322, 153, 209, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/doctor2.jpg"))); // NOI18N
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(-60, 0, 920, 540));

        add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 720, 509));
    }// </editor-fold>//GEN-END:initComponents

    private void jbtnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCreateActionPerformed
      
        String name = txtDoctorName.getText();
        String qualification = txtQuali.getText();
        String specilization = txtSpeci.getText();
        String userName = txtName.getText();
         char[] passwordCharArray = txtPasswd.getPassword();
        String password = String.valueOf(passwordCharArray);
        Boolean emergencyDoc = chkboxEmeDoctor.isSelected();
        OrganizationService doctororg = null;
            
        for(Venture enterprise : network.getVentureDirectory().getVentureList())
        {
            for (OrganizationService organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
               if (organization instanceof DoctorOrganizationService ) {
                   doctororg = organization;
                   break;
               }
           }
        }
         doctorList.addNewwDoctor(name,qualification,specilization,emergencyDoc);
        Employee employee = ecoSystem.getEmployeeeDirectory().createEmployee(name);
        if(emergencyDoc)
        {
            UserAccountService usseraccount = doctororg.getUserAccounttDirectory().createUserAccount(userName, password, employee, new EmergencyDoctorRoleService());
        }
        else
        {  
            UserAccountService usseraccount = doctororg.getUserAccounttDirectory().createUserAccount(userName, password, employee, new DoctorRoleService());
        }

        JOptionPane.showMessageDialog(null, "Doctor Profile Created");
        
    }//GEN-LAST:event_jbtnCreateActionPerformed

    private void jkButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jkButton2ActionPerformed
        // TODO add your handling code here:
        userProcessContainer.remove(this);
        Component[] componentArray = userProcessContainer.getComponents();
        Component component = componentArray[componentArray.length - 1];
        PatientListJPanel mcjp = (PatientListJPanel) component;
        mcjp.populateDocTable();
        CardLayout layout = (CardLayout) userProcessContainer.getLayout();
        layout.previous(userProcessContainer);
    }//GEN-LAST:event_jkButton2ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox chkboxEmeDoctor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton jbtnCreate;
    private javax.swing.JButton jkButton2;
    private javax.swing.JTextField txtDoctorName;
    private javax.swing.JTextField txtName;
    private javax.swing.JPasswordField txtPasswd;
    private javax.swing.JTextField txtQuali;
    private javax.swing.JTextField txtSpeci;
    // End of variables declaration//GEN-END:variables
}
