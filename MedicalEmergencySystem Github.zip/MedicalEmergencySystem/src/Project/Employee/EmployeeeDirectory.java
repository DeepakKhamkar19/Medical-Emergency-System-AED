package Project.Employee;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class EmployeeeDirectory {
    
    private ArrayList<Employee> employeeList;
    // Creating an arraylist of type employee named employeelist
    public EmployeeeDirectory() {
        employeeList = new ArrayList();
    }

    public ArrayList<Employee> getEmployeeList() {
        return employeeList;
    }
    
    public Employee createEmployee(String name){
        Employee employee = new Employee();
        //Setting name of employee using the setName method in the class
        employee.setName(name);
        //Adding the employee to the list 
        employeeList.add(employee);
        //Returning the created employee
        return employee;
    }
}