package Project.Employee;

/**
 *
 * @author Dell
 */
public class Employee {
    
    private String name;
    private int id;
    private static int count = 1;
    //DEclaring variables to create an employee class

    public Employee() {
        id = count;
        count++;
        //incrementing cont when id is equal to count in the system 
    }

    public int getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return name;
    }
    // Using toString method of String class to convert an object to String
    
}
