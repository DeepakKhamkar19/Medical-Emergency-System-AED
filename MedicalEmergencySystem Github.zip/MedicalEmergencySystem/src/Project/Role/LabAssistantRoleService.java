/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

import Project.EcoSystem;
import Project.Venture.Venture;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import Project.UserAccount.UserAccountService;
import javax.swing.JPanel;
import userinterface.EmergencyUnitAdminArea.EmergencyUnitAdminWorkAreaJPanel;
import userinterface.LabWorkArea.LabWorkAreaJPanel;

/**
 *
 * @author Dell
 */
public class LabAssistantRoleService extends RoleService {

  
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccountService acc, OrganizationService org, Venture venture, NetworkService net, EcoSystem project) {
         return new LabWorkAreaJPanel(userProcessContainer,acc,org,venture,net,project);
    }

     @Override
    public String toString(){
        return (RoleType.LabAssistantRoleService.getValue());
    }
}
