/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

import Project.EcoSystem;
import Project.Venture.Venture;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import Project.UserAccount.UserAccountService;
import javax.swing.JPanel;
import userinterface.BillingWorkArea.BillingWorkArea;

/**
 *
 * @author Dell
 */
public class BillingAdminRoleService extends RoleService{
    public JPanel createWorkArea(JPanel userProcessContainer, 
          UserAccountService acc,OrganizationService org,Venture enterprise,NetworkService net,EcoSystem project) {
        return  new BillingWorkArea(userProcessContainer ,net,enterprise, org , acc,  project);
    }
    
     
    @Override
    public String toString(){
        return (RoleType.BillingAdminRoleService.getValue());
    }
}