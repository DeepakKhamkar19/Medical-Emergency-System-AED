/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

import Project.EcoSystem;
import Project.Venture.Venture;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import Project.UserAccount.UserAccountService;
import javax.swing.JPanel;
import userinterface.EmergencyUnitAdminArea.EmergencyUnitAdminWorkAreaJPanel;
import userinterface.EquipmentUnitAdminArea.EquipmentUnitAdminWorkArea2JPanel;
import userinterface.EquipmentWorkArea.EquipmentWorkAreaJPanel;

/**
 *
 * @author Dell
 */
public class EquipmeentAdminService extends RoleService {
    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccountService acc,OrganizationService org,Venture venture,NetworkService net, EcoSystem project) {
        return new EquipmentWorkAreaJPanel( userProcessContainer,acc,net,venture,org, project);
    }
    
     @Override
    public String toString(){
        return (RoleType.EquipmentAdminService.getValue());
    }
}
