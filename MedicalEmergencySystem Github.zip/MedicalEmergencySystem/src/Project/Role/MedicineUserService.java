/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

import Project.EcoSystem;
import Project.Venture.Venture;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import Project.UserAccount.UserAccountService;
import javax.swing.JPanel;
import userinterface.EmergencyUnitAdminArea.EmergencyUnitAdminWorkAreaJPanel;
import userinterface.MedicineUnitAdminArea.MedicineUnitAdminWorkAreaJPanel;
import userinterface.MedicineUnitArea.PharmacyWorkArea;
import userinterface.MedicineUnitArea.PharmacyWorkArea2;

/**
 *
 * @author Dell
 */
public class MedicineUserService extends RoleService{
     @Override
    public JPanel createWorkArea(JPanel userProcessContainer, UserAccountService acc,OrganizationService org,Venture venture,NetworkService net, EcoSystem project) {
        return new PharmacyWorkArea( userProcessContainer,acc,org,venture,net, project);
    }
    
     @Override
    public String toString(){
        return (RoleType.MedicineUserService.getValue());
    }
}
