/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

//import Business.Customer.CustomerDirectory;
import Project.EcoSystem;
import Project.Venture.Venture;
import Project.MedicalEmployment.PatienttList;
import Project.Network.NetworkService;

import Project.Organization.OrganizationService;
////import Business.Restaurant.RestaurantDirectory;
import Project.UserAccount.UserAccountService;
//import userinterface.CustomerRole.CustomerAreaJPanel;
import javax.swing.JPanel;
import userinterface.Receptionist.PatientListJPanel;

/**
 *
 * @author Dell
 */

public class ReceptionistRoleService extends RoleService{

    @Override
      public JPanel createWorkArea(JPanel userProcessContainer, UserAccountService acc,
              OrganizationService org,Venture venture,
              NetworkService net, EcoSystem project) {
        return new  PatientListJPanel(userProcessContainer,net,org,project);
       // return null;
        //return new CustomerAreaJPanel(userProcessContainer, account,business);
    }
    
       @Override
    public String toString(){
        return (RoleType.ReceptionistRoleService.getValue());
    }
    
}
