/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

//import Business.Customer.CustomerDirectory;
import Project.EcoSystem;
import Project.Venture.Venture;
import Project.MedicalEmployment.PatienttList;
import Project.Network.NetworkService;

import Project.Organization.OrganizationService;
import Project.UserAccount.UserAccountService;
import javax.swing.JPanel;

/**
 *
 * @author Dell
 */
public abstract class RoleService {
    
    public enum RoleType{
        AccountingAdminRoleService("AccountingAdminRole"),
        AdminRoleService("AdminRole"),
        AmbulanceRoleService("AmbulanceRole"),
        BillingAdminRoleService("BillingAdminRole"),
        DoctorRoleService("DoctorRole"),
        EmergencyAdminRoleService("EmergencyAdminRole"),
        EmergencyDoctorRoleService("EmergencyDoctorRole"),
        EmergencyUserRoleService("EmergencyUserRole"),
        EquipmentAdminService("EquipmentAdmin"),
        LabAssistantRoleService("LabAssistantRole"),
        ManagementAdminRoleService("ManagementAdminRole"),
        MedicineAdminService("MedicineAdmin"),
        MedicineUserService("MedicineUser"),
        PatientRoleService("PatientRole"),
        PersonRoleService("PersonRole"),
        ReceptionistRoleService("ReceptionistRole"),
        SystemAdminRoleService("SystemAdminRole");
        
        private String value;
        private RoleType(String value){
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
    
    public abstract JPanel createWorkArea(JPanel userProcessContainer, 
            UserAccountService acc,OrganizationService org,Venture venture,NetworkService net,
            EcoSystem project);

    @Override
    public String toString() {
       return  this.getClass().getName();
    }
    
    
}