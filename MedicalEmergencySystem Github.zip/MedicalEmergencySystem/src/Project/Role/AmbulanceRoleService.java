/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

//import Business.Customer.CustomerDirectory;
import Project.EcoSystem;
import Project.Venture.Venture;
import Project.MedicalEmployment.PatienttList;
import Project.Network.NetworkService;

import Project.Organization.OrganizationService;
////import Business.Restaurant.RestaurantDirectory;
import Project.UserAccount.UserAccountService;
//import userinterface.CustomerRole.CustomerAreaJPanel;
import javax.swing.JPanel;
import userinterface.Ambulance.EmergencyAmbulanceUserJPanel;

/**
 *
 * @author Dell
 */
public class AmbulanceRoleService extends RoleService{

    
    public JPanel createWorkArea(JPanel userProcessContainer, 
            UserAccountService acc,OrganizationService org,Venture venture,NetworkService net,
            EcoSystem project) {
        return new EmergencyAmbulanceUserJPanel(userProcessContainer, acc,org,venture,net,project);
        //return null;
        //return new CustomerAreaJPanel(userProcessContainer, account,business);
    }
    
     @Override
    public String toString(){
        return (RoleType.AmbulanceRoleService.getValue());
    }
}
