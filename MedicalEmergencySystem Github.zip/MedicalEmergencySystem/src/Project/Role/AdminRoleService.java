/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Role;

//import Business.Customer.CustomerDirectory;
import Project.EcoSystem;
import Project.Venture.Venture;
import Project.MedicalEmployment.PatienttList;
import Project.Network.NetworkService;

import Project.Organization.OrganizationService;
//import Business.Restaurant.RestaurantDirectory;
import Project.UserAccount.UserAccountService;
//import userinterface.RestaurantAdminRole.AdminWorkAreaJPanel;
import javax.swing.JPanel;
import userinterface.EmergencyUnitAdminArea.EmergencyUnitAdminWorkAreaJPanel;
import userinterface.SystemAdminWorkArea.SystemAdminWorkAreaJPanel;

/**
 *
 * @author Dell
 */
public class AdminRoleService extends RoleService{

    @Override
    public JPanel createWorkArea(JPanel userProcessContainer, 
            UserAccountService acc,OrganizationService org,Venture venture,NetworkService net,
            EcoSystem project) {
       // return null;
        
        //userProcessContainer, business, account,restaurantDirectory
//        return null;
        return new EmergencyUnitAdminWorkAreaJPanel(userProcessContainer, venture, project);
       
    }

    @Override
    public String toString(){
        return (RoleType.AdminRoleService.getValue());
    }
    
}
