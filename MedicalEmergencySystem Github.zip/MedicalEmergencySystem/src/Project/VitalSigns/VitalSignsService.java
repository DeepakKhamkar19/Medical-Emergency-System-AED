/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.VitalSigns;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class VitalSignsService {
    
    private int respiratoryyRate;
    private int blooddPressure;
    private int weightt;
    private int heartRate;
    private Date datee;
    
    public int getRespiratoryyRate() {
        return respiratoryyRate;
    }

    public void setRespiratoryyRate(int respiratoryyRate) {
        this.respiratoryyRate = respiratoryyRate;
    }

    public int getBlooddPressure() {
        return blooddPressure;
    }

    public void setBlooddPressure(int blooddPressure) {
        this.blooddPressure = blooddPressure;
    }

    public int getWeightt() {
        return weightt;
    }

    public void setWeightt(int weightt) {
        this.weightt = weightt;
    }

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }

    public Date getDatee() {
        SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm:ss a");
        return datee;
    }

    public void setDatee(Date datee) {
        SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm:ss a");
        this.datee = datee;
    }

    @Override
    public String toString() {
        SimpleDateFormat ft = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm:ss a");
        return ft.format(datee);
    }
}
