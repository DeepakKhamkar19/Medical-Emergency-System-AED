/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Role.BillingAdminRoleService;
import Project.Role.PatientRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class BillingOrganizationService extends OrganizationService {

    double funds;
    
    public BillingOrganizationService() {
        super(OrganizationService.Type.BillingDepartmentService.getVal());
    }
    public BillingOrganizationService(String billName){
        super(billName);
    }

    
     @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
        roles.add(new BillingAdminRoleService());
        return roles;
    }
    
    @Override
    public Type getTypee() {
        return OrganizationService.Type.BillingDepartmentService;
    } 

    public double getFunds() {
        return funds;
    }

    public void setFunds(double funds) {
        this.funds = funds;
    }

    
    
}
