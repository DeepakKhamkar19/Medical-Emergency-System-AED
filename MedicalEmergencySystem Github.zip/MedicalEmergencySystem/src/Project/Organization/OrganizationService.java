/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Employee.EmployeeeDirectory;
import Project.Role.RoleService;
import Project.UserAccount.UserAccDirectoryService;
import Project.WorkQueue.WorkkQueueService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public abstract class OrganizationService {

    private String orgName;
    private WorkkQueueService workkQueue;
    private EmployeeeDirectory employeeeDirectory;
    private UserAccDirectoryService userAccounttDirectory;
    private int orgID;
    private static int count = 0;
    public ArrayList<RoleService> role;
    private Type typee;
    
    public enum Type{
        LabDepartmentService("Lab Department"),
        DoctorDepartmentService("Doctor Department"),
        EmergencyDepartmentService("Emergency Department"),
        ReceptionistDepartmentService("Receptionist Department"),
        AmbulanceDepartmentService("Ambulance Department"),
        PatientDepartmentService("Patient Department"),                
        BillingDepartmentService("Billing Department"),
        MedicineDepartmentService("Medicine Department"),
        EquipmentDepartmentService("Equipment Department"),
        PersonDepartmentService("Person Department"),
        AdminDepartmentService("Admin Department");
        
        
        private String val;
        private Type(String val) {
            this.val = val;
        }
        public String getVal() {
            return val;
        }
        
        @Override
        public String toString(){
        return val;
        }
    }
    
        public Type getTypee() {
            return typee;
        }

        public void setTypee(Type typee) {
            this.typee = typee;
        }


    public OrganizationService(String orgName) {
        this.orgName = orgName;
        workkQueue = new WorkkQueueService();
        employeeeDirectory = new EmployeeeDirectory();
        userAccounttDirectory = new UserAccDirectoryService();
        orgID = count;
        ++count;
    }
    public OrganizationService(){
        
    }
    public abstract ArrayList<RoleService> getSupportedRole();
    
    public UserAccDirectoryService getUserAccounttDirectory() {
        return userAccounttDirectory;
    }

    public int getOrgID() {
        return orgID;
    }

    public EmployeeeDirectory getEmployeeeDirectory() {
        return employeeeDirectory;
    }
    
    public String getOrgName() {
        return orgName;
    }

    public WorkkQueueService getWorkkQueue() {
        return workkQueue;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public void setWorkkQueue(WorkkQueueService workkQueue) {
        this.workkQueue = workkQueue;
    }

    @Override
    public String toString() {
        return orgName;
    }
    
    
}
