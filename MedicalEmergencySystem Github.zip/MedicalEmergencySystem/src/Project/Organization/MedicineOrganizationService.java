/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Medicine.MedicineService;
import Project.Role.LabAssistantRoleService;
import Project.Role.MedicineAdminService;
import Project.Role.MedicineUserService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class MedicineOrganizationService extends OrganizationService{
    private ArrayList<MedicineService> medList;
    
    public MedicineOrganizationService() {
        super(OrganizationService.Type.MedicineDepartmentService.getVal());
    }
    public MedicineOrganizationService(String medOrgName){
        super(medOrgName);
          medList=new ArrayList<MedicineService>();
    }

    @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
       // roles.add(new MedicineAdminService());
        roles.add(new MedicineUserService());
        return roles;
    }
    
    @Override
    public Type getTypee() {
        return OrganizationService.Type.MedicineDepartmentService;
    } 

     public ArrayList<MedicineService> getMedList() {
        return medList;
    }

    public void setMedList(ArrayList<MedicineService> medList) {
        this.medList = medList;
    }
    
     public void addMedicine(MedicineService med)
    {
       
        medList.add(med);
        
    }
}
