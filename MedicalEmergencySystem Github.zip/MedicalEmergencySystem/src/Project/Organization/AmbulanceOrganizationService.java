/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Role.AmbulanceRoleService;
import Project.Role.EmergencyAdminRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class AmbulanceOrganizationService extends OrganizationService {

    public AmbulanceOrganizationService() {
        super(OrganizationService.Type.AmbulanceDepartmentService.getVal());
    }
    
      public AmbulanceOrganizationService(String ambName) {
        super(ambName);
    }
    
      @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
        roles.add(new AmbulanceRoleService());
        return roles;
    }
    
        @Override
    public Type getTypee() {
        return OrganizationService.Type.AmbulanceDepartmentService;
    } 

}
