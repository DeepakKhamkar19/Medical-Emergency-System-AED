/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Medicine.PrescriptionService;
import Project.Role.DoctorRoleService;
import Project.Role.EmergencyDoctorRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class DoctorOrganizationService extends OrganizationService {

    private ArrayList<PrescriptionService> prescriiptionlist;
    
    
    public DoctorOrganizationService() {
        super(OrganizationService.Type.DoctorDepartmentService.getVal());
        prescriiptionlist=new ArrayList<PrescriptionService>();
    }
     public DoctorOrganizationService(String docOrgName){
        super(docOrgName);
    }

     public ArrayList<PrescriptionService> getPrescriiptionlist() {
        return prescriiptionlist;
    }

    public void setPrescriiptionlist(ArrayList<PrescriptionService> prescriiptionlist) {
        this.prescriiptionlist = prescriiptionlist;
    }
    
     
    @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
        roles.add(new EmergencyDoctorRoleService());
        roles.add(new DoctorRoleService());
        return roles;
    }
    
    @Override
    public Type getTypee() {
        return OrganizationService.Type.DoctorDepartmentService;
    } 
    
    public void addPrescription(PrescriptionService prescriiption){
        
         prescriiptionlist.add(prescriiption);
         
        
    }


}
