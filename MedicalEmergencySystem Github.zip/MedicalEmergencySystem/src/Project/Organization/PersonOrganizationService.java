/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Role.MedicineAdminService;
import Project.Role.PersonRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class PersonOrganizationService extends OrganizationService {
    
    public PersonOrganizationService(){
        super(OrganizationService.Type.PersonDepartmentService.getVal());
    }
    public PersonOrganizationService(String personOrgName){
        super(personOrgName);
    }
    @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
        roles.add(new PersonRoleService());
        return roles;
    }
    @Override
    public Type getTypee() {
        return OrganizationService.Type.PersonDepartmentService;
    } 
}
