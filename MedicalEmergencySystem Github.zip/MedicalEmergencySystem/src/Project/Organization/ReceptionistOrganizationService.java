/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Role.EmergencyDoctorRoleService;
import Project.Role.LabAssistantRoleService;
import Project.Role.ReceptionistRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class ReceptionistOrganizationService extends OrganizationService {

    public ReceptionistOrganizationService() {
        super(OrganizationService.Type.ReceptionistDepartmentService.getVal());
    
    }  
    public ReceptionistOrganizationService(String recOrgName) {
            super(recOrgName);
    }
        

    @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
        roles.add(new ReceptionistRoleService());
        return roles;
    }
    
     @Override
    public Type getTypee() {
        return OrganizationService.Type.ReceptionistDepartmentService;
    } 

}
