/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Role.EmergencyDoctorRoleService;
import Project.Role.EmergencyAdminRoleService;
import Project.Role.EmergencyUserRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class EmergencyOrganizationService extends OrganizationService {

    public EmergencyOrganizationService() {
        super(OrganizationService.Type.EmergencyDepartmentService.getVal());
        
    }
    
    public EmergencyOrganizationService(String emeOrgName){
        super(emeOrgName);
    }

    @Override
    public ArrayList<RoleService> getSupportedRole() {
        ArrayList<RoleService> roles = new ArrayList<>();
       
        roles.add(new EmergencyUserRoleService());
        return roles;
    }
    
    @Override
    public Type getTypee() {
        return OrganizationService.Type.EmergencyDepartmentService;
    } 


}
