/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Organization;

import Project.Venture.Emergency;
import Project.Role.EmergencyAdminRoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class OrganizationDirectory {
    private ArrayList<OrganizationService> organizationList;
    
    public OrganizationDirectory()
    {
        organizationList = new ArrayList<OrganizationService>();
    }

    public ArrayList<OrganizationService> getOrganizationList() {
        return organizationList;
    }

    public void setOrganizationList(ArrayList<OrganizationService> organizationList) {
        this.organizationList = organizationList;
    }
    
    public OrganizationService createOrganization(OrganizationService.Type type,String name) {
        OrganizationService organization = null;
        if (type.getVal().equals(OrganizationService.Type.EmergencyDepartmentService.getVal())) {
            organization = new EmergencyOrganizationService(name);
            organizationList.add(organization);
        } 
        else if (type.getVal().equals(OrganizationService.Type.LabDepartmentService.getVal())) {
            organization = new LabOrganizationService(name);
            organizationList.add(organization);
        } 
        else if (type.getVal().equals(OrganizationService.Type.DoctorDepartmentService.getVal())){
                    organization=new DoctorOrganizationService(name);
                    organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.BillingDepartmentService.getVal())){
                    organization=new BillingOrganizationService(name);
                    organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.AmbulanceDepartmentService.getVal())){
                    organization=new AmbulanceOrganizationService(name);
                    organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.MedicineDepartmentService.getVal())){
                  organization=new MedicineOrganizationService(name);
                  organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.PatientDepartmentService.getVal())){
                  organization=new PatientOrganizationService(name);
                  organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.EquipmentDepartmentService.getVal())){
                 organization=new EquipmentOrganizationService(name);
                 organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.PersonDepartmentService.getVal())){
                 organization=new PersonOrganizationService(name);
                 organizationList.add(organization);
        }
        else if (type.getVal().equals(OrganizationService.Type.ReceptionistDepartmentService.getVal())){
                 organization=new ReceptionistOrganizationService(name);
                 organizationList.add(organization);
        }
        
        return organization;
    }
    
}
