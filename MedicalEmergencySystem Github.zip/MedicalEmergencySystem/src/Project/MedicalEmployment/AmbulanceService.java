
package Project.MedicalEmployment;
/**
 *
 * @author Dell
 */
public class AmbulanceService {
    String driverrName;
    String ambulanceeNumber;
    String locationn;
    private double longitudee;
    private double latitudee;
    //Decalring varibles for class Ambulance service 
    
    public AmbulanceService(String driverrName,String ambulanceeNumber,String locationn)
    {
        this.ambulanceeNumber = ambulanceeNumber;
        this.driverrName = driverrName;
        this.locationn = locationn;
        //Assigning the created variable to class variables
    }
    
    public String getDriverrName() {
        return driverrName;
    }

    public void setDriverrName(String driverrName) {
        this.driverrName = driverrName;
    }

    public String getAmbulanceeNumber() {
        return ambulanceeNumber;
    }

    public void setAmbulanceeNumber(String ambulanceeNumber) {
        this.ambulanceeNumber = ambulanceeNumber;
    }

    public String getLocationn() {
        return locationn;
    }

    public void setLocationn(String locationn) {
        this.locationn = locationn;
    }

    public double getLongitudee() {
        return longitudee;
    }

    public void setLongitudee(double longitudee) {
        this.longitudee = longitudee;
    }

    public double getLatitudee() {
        return latitudee;
    }

    public void setLatitudee(double latitudee) {
        this.latitudee = latitudee;
    }
    
    @Override
    public String toString()
    {
        return ambulanceeNumber;
    }
    // Using the toString() method 
    // from the String class to change the variables to string 
}
