
package Project.MedicalEmployment;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class PatienttList {
    private ArrayList<PatientDetails> patienttList;
    //Creating an array list pbject of type patientdetails named patient list 

    public PatienttList() {
        patienttList = new ArrayList<PatientDetails>();
    }

    public ArrayList<PatientDetails> getPatienttList() {
        return patienttList;
        //returning the newly created array list object 
    }

    public void setPatienttList(ArrayList<PatientDetails> patienttList) {
        this.patienttList = patienttList;
    }
    
      public PatientDetails addNewPatient(String patName, String emailId, String phoneNo, int patAge, String homeAdd, 
              String userrName, Date dob,String bloodGroup,String doc,String Gender,String locaation)
    {
        PatientDetails patientt = new PatientDetails(patName,emailId,phoneNo,patAge, homeAdd,userrName,dob,bloodGroup,
                doc,Gender,locaation);
        patienttList.add(patientt);
        return patientt;
        // returning the newly created patient
    }
    
    public void removePatient(PatientDetails patientt)
    {
        patienttList.remove(patientt);
    }
    
}
