package Project.MedicalEmployment;

import Project.Medicine.PrescriiptionnList;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class PatientDetails {
    
    private int patId;
    private String patName;
    private int patAge;
    private String patGender;
    private String patTest;
    private String doctorr;
    private PatienttHistory patiHistory;
    private String emailAdd;
    private  String add; 
    private String userrName;
    private String phoneNo;
    private Date dob;
    private String bloodGroup;
    private PrescriiptionnList prescriptionList;
    private static int patienttCount=1;
   private String locaation;
   
   //Declaring varibles for patient details class
    
    public PatientDetails(String firsttName, String emailId, String phoneNo, int patAge, String homeAdd, 
            String userrName, Date dob,String bloodGroup,String doctor,String patGender,String locaation){
        this.patName = firsttName;
        this.emailAdd = emailId;
        this.phoneNo = phoneNo;
        this.patAge = patAge;
        this.add = homeAdd;
        this.userrName = userrName;
        this.patId = patienttCount;
        this.dob = dob;
        this.doctorr = doctor;
        this.patGender = patGender;
        this.bloodGroup = bloodGroup;
        this.locaation = locaation;
        this.prescriptionList = new PrescriiptionnList();
        patienttCount++;
        // Using the created varibles and assigning them to the class varoiables 
    }

    public String getLocaation() {
        return locaation;
    }

    public void setLocaation(String locaation) {
        this.locaation = locaation;
    }

    public PrescriiptionnList getPrescriptionList() {
        return prescriptionList;
    }

    public void setPrescriptionList(PrescriiptionnList prescriptionList) {
        this.prescriptionList = prescriptionList;
    }

    public String getDoctorr() {
        return doctorr;
    }

    public void setDoctorr(String doctorr) {
        this.doctorr = doctorr;
    }
    
    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }
   
    public int getPatId() {
        return patId;
    }

    public void setPatId(int patId) {
        this.patId = patId;
    }

    public String getPatName() {
        return patName;
    }

    public void setPatName(String patName) {
        this.patName = patName;
    }

    public int getPatAge() {
        return patAge;
    }

    public void setPatAge(int patAge) {
        this.patAge = patAge;
    }

    public String getPatGender() {
        return patGender;
    }

    public void setPatGender(String patGender) {
        this.patGender = patGender;
    }

    public String getPatTest() {
        return patTest;
    }

    public void setPatTest(String patTest) {
        this.patTest = patTest;
    }

    public PatienttHistory getPatiHistory() {
        return patiHistory;
    }

    public void setPatiHistory(PatienttHistory patiHistory) {
        this.patiHistory = patiHistory;
    }
    public String getEmailAdd() {
        return emailAdd;
    }

    public void setEmailAdd(String emailAdd) {
        this.emailAdd = emailAdd;
    }

    public String getUserrName() {
        return userrName;
    }

    public void setUserrName(String userrName) {
        this.userrName = userrName;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }
 
    @Override
     public String toString()
     {
         return this.patName;
     }
     // Using to string ()
     //method of the String class
     // to convert variables to string format 
        
}
