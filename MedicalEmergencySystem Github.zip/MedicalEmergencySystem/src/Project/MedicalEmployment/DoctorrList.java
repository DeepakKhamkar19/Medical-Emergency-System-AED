package Project.MedicalEmployment;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class DoctorrList {
   private ArrayList<DoctorService> doctorrList;
   //Creating an array list of type Doctor service named doctor list 

    public DoctorrList() {
        this.doctorrList = new ArrayList<DoctorService>() ;
    }
   
      public DoctorService addNewwDoctor(String fullNaame, String qualificaation, String specilizaation, Boolean emeeDoc)
    {
        //Creating an object named doc 
        DoctorService doc = new DoctorService(fullNaame,qualificaation,specilizaation,emeeDoc);
        doctorrList.add(doc);
        //Retuning the 
        //newly created object 
        return doc;
    }

    public ArrayList<DoctorService> getDoctorrList() {
        return doctorrList;
    }

    public void setDoctorrList(ArrayList<DoctorService> doctorrList) {
        this.doctorrList = doctorrList;
    }
   
    public void removeeDoctor(DoctorService doc)
    {
        doctorrList.remove(doc);
    }
   
}
