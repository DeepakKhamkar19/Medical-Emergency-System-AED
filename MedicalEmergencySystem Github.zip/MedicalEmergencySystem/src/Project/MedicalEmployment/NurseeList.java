
package Project.MedicalEmployment;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class NurseeList {
    
    private  ArrayList<NurseService> nurseeList;
    //Creating an array list of type nurse service 
    //named nurseelist 

    public NurseeList() {
        this.nurseeList = new ArrayList<NurseService>() ;
    }
 
    public ArrayList<NurseService> getNurseeList() {
        return nurseeList;
    }

    public void setNurseeList(ArrayList<NurseService> nurseeList) {
        this.nurseeList = nurseeList;
    } 
    
}
