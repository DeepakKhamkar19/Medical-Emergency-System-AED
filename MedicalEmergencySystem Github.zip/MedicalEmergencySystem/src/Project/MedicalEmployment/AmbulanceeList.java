package Project.MedicalEmployment;

import java.util.ArrayList;
import java.util.Date;
/**
 *
 * @author Dell
 */
public class AmbulanceeList {
     private ArrayList<AmbulanceService> ambulanceeList;

    public AmbulanceeList() {
        this.ambulanceeList = new ArrayList<AmbulanceService>() ;
    }
    
     public AmbulanceService addNewAmbulancee(String name,  String number, String homeAddress)
    {
        //Creating new Ambulance service object using this method 
        AmbulanceService ambulanceservice = new AmbulanceService(name,number,homeAddress);
        ambulanceeList.add(ambulanceservice);
        // retuning the created ambulance service object 
        return ambulanceservice;
    }
     
    public ArrayList<AmbulanceService> getambulanceList() {
        return ambulanceeList;
    }

    public void setambulanceeList(ArrayList<AmbulanceService> ambulanceeList) {
        this.ambulanceeList = ambulanceeList;
    }  
}
