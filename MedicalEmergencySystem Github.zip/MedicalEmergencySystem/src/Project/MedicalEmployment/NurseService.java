package Project.MedicalEmployment;

/**
 *
 * @author Dell
 */
public class NurseService {
    private String nurseName;
    private String nursePosition;
    //Declaring varoiables for the class nurse 

    public String getNurseName() {
        return nurseName;
    }

    public void setNurseName(String nurseName) {
        this.nurseName = nurseName;
    }

    public String getNursePosition() {
        return nursePosition;
    }

    public void setNursePosition(String nursePosition) {
        this.nursePosition = nursePosition;
    }
    // Getter and Setters methods created 
    
    
}
