package Project.MedicalEmployment;

import java.util.Date;

/**
 *
 * @author Dell
 */
public class PatienttHistory {
    
    private String issue;
    private Date createeDate;
    PatientDetails patientt;
    DoctorService doc;
    //Declaring variables for class patient history

    public String getIssue() {
        return issue;
    }

    public void setIssue(String issue) {
        this.issue = issue;
    }

    public Date getCreateeDate() {
        return createeDate;
    }

    public void setCreateeDate(Date createeDate) {
        this.createeDate = createeDate;
    }

    public PatientDetails getPatientt() {
        return patientt;
    }

    public void setPatientt(PatientDetails patientt) {
        this.patientt = patientt;
    }
    
    
}
