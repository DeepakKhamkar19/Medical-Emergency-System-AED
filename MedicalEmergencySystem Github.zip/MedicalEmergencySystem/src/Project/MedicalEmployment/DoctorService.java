package Project.MedicalEmployment;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class DoctorService {
    private String patienttName;
    private int patientAge;
    private String patientGender;
    private String docQualification;
    private Date practicingFrom ;
    private String specilizationnName;
    private String DoctorName;
    private Boolean emergencyDoctorr;
    //Declaring varibles in the doctor service class 

    public DoctorService(String DocName,String qualification, String specilizationName,Boolean emergencyDoctor ) {
        this.docQualification = qualification;
        this.specilizationnName = specilizationName;
        this.DoctorName = DocName;
        this.emergencyDoctorr = emergencyDoctor;
        //Assigning these variables to class variables 
    }

    public Boolean getEmergencyDoctorr() {
        return emergencyDoctorr;
    }

    public void setEmergencyDoctorr(Boolean emergencyDoctorr) {
        this.emergencyDoctorr = emergencyDoctorr;
    }
   
    public String getDoctorName() {
        return DoctorName;
    }

    public void setDoctorName(String DoctorName) {
        this.DoctorName = DoctorName;
    }

    public String getPatienttName() {
        return patienttName;
    }

    public void setPatienttName(String patienttName) {
        this.patienttName = patienttName;
    }

    public int getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(int patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientGender() {
        return patientGender;
    }

    public void setPatientGender(String patientGender) {
        this.patientGender = patientGender;
    }

    public String getDocQualification() {
        return docQualification;
    }

    public void setDocQualification(String docQualification) {
        this.docQualification = docQualification;
    }

    public Date getPracticingFrom() {
        return practicingFrom;
    }

    public void setPracticingFrom(Date practicingFrom) {
        this.practicingFrom = practicingFrom;
    }

    public String getSpecilizationnName() {
        return specilizationnName;
    }

    public void setSpecilizationnName(String specilizationnName) {
        this.specilizationnName = specilizationnName;
    }
    
    @Override
    public String toString()
    {
        return DoctorName;
    }
    // Using the toString Method
    //from String class to convert varibles to string format 
}
