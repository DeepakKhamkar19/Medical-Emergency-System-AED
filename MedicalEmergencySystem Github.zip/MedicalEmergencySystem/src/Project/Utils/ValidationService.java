/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Utils;

import java.awt.event.KeyEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Dell
 */
public class ValidationService {
    
    public static boolean validateName(String namee) {
        Pattern patternn;
        Matcher matcherr;
        String NAME_PATTERNN = "^[A-Za-z]{1,}[\\s]{0,1}[A-Za-z]{0,}$";
        patternn = Pattern.compile(NAME_PATTERNN);
        matcherr = patternn.matcher(namee);
        return matcherr.matches();
    }
    
        public static boolean validateUserName(String namee) {
        Pattern patternn;
        Matcher matcherr;
        String NAME_PATTERNN = "^[A-Za-z\\s]+$";
        patternn = Pattern.compile(NAME_PATTERNN);
        matcherr = patternn.matcher(namee);
        return matcherr.matches();
    }
        
        
        public static boolean validateEmail(String emailId) {
        Pattern patternn;
        Matcher matcherr;
        String EMAIL_PATTERNN
                = "^[\\w!#$%&’*+/=?`{|}~^-]+(?:\\.[\\w!#$%&’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
        patternn = Pattern.compile(EMAIL_PATTERNN);
        matcherr = patternn.matcher(emailId);
        return matcherr.matches();
    }

    public static boolean validatePassword(String passwrdValue) {
        Pattern pattern;
        Matcher matcher;
        String PASSWORD_PATTERNN
                = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&+=~|?])(?=\\S+$).{8,}$";
        pattern = Pattern.compile(PASSWORD_PATTERNN);
        matcher = pattern.matcher(passwrdValue);
        return matcher.matches();
    }

    public static boolean validatePhoneNumber(String contactNo) {
        Pattern patternn;
        Matcher matcherr;
        String PHONE_PATTERNN = "^[0-9]{10}$";
        patternn = Pattern.compile(PHONE_PATTERNN);
        matcherr = patternn.matcher(contactNo);
        return matcherr.matches();
    }

    public static void validateString(KeyEvent evnt, JTextField field1) {
        char c = evnt.getKeyChar();
        if (!((c >= 'A') && (c <= 'Z') || (c >= 'a') && (c <= 'z') || (c == evnt.VK_SPACE)
                || (c == evnt.VK_BACK_SPACE)
                || (c == evnt.VK_DELETE))) {

            JOptionPane.showMessageDialog(null, "Enter Alphabets only");
            field1.setText(field1.getText().substring(0, field1.getText().length()-1));
        }
    }

    public static void validateInteger(KeyEvent evnt, JTextField field1) {
        char c = evnt.getKeyChar();
        if (!((c >= '0') && (c <= '9')
                || (c == evnt.VK_BACK_SPACE)
                || (c == evnt.VK_DELETE))) {

            JOptionPane.showMessageDialog(null, "Enter Integers only");
            field1.setText("");
            field1.setText(field1.getText().substring(0, field1.getText().length()-1));
        }
    }
    
}
