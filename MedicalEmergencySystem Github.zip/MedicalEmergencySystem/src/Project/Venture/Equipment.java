/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Venture;

import Project.Role.EquipmeentAdminService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Equipment extends Venture {
   public Equipment(String name) {
    super(name, Venture.VentureType.EquipmentUnit);
   }
    @Override
    
    public ArrayList<RoleService> getSupportedRole() {
        role = new ArrayList<RoleService>();
        role.add(new EquipmeentAdminService());
       //  role.add(new PoliceHead());
        return role;
    }
}
