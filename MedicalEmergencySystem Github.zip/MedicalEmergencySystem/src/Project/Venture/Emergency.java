/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Venture;

import Project.Role.AmbulanceRoleService;
import Project.Role.EmergencyDoctorRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;
import Project.Role.EmergencyAdminRoleService;
import Project.Role.LabAssistantRoleService;
import Project.Role.PatientRoleService;
import Project.Role.ReceptionistRoleService;

/**
 *
 * @author Dell
 */
public class Emergency extends Venture {
    
    public Emergency(String name) {
        super(name, Venture.VentureType.EmergencyUnit);
    }

    @Override
    
    public ArrayList<RoleService> getSupportedRole() {
        role = new ArrayList<RoleService>();
        role.add(new EmergencyAdminRoleService());
        role.add(new EmergencyDoctorRoleService());
        role.add(new AmbulanceRoleService());
        role.add(new PatientRoleService());
        role.add(new LabAssistantRoleService());
        role.add(new ReceptionistRoleService());
       //  role.add(new PoliceHead());
        return role;
    }
    
}
