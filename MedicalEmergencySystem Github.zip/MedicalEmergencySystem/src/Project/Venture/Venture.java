/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Venture;
import Project.Organization.OrganizationService;
import Project.Organization.OrganizationDirectory;

/**
 *
 * @author Dell
 */
public abstract class Venture extends OrganizationService {
    
    private VentureType enterpriseType;
    private OrganizationDirectory organizationDirectory;
    private OrganizationService organization;

    public OrganizationDirectory getOrganizationDirectory() {
        return organizationDirectory;
    }


    public enum VentureType{
        EmergencyUnit("Emrgncy Unit"), 
        Accounting("Account Unit"), 
        ManagementUnit("Management Unit"),   /*, FundsOperatingUnit("Funds Operating Unit")*/
        MedicalUnit("Medical Unit"),
        EquipmentUnit("Equipment Unit");
        
        
        
        private String value;
        
        private VentureType(String value){
            this.value=value;
        }
        public String getValue() {
            return value;
        }
        @Override
        public String toString(){
        return value;
    }
    }

    public VentureType getEnterpriseType() {
        return enterpriseType;
    }

    public void setEnterpriseType(VentureType enterpriseType) {
        this.enterpriseType = enterpriseType;
    }
    
    public Venture(String name,VentureType type){
        super(name);
        this.enterpriseType=type;
        organizationDirectory=new OrganizationDirectory();
    }

    public OrganizationService getOrganization() {
        return organization;
    }

    public void setOrganization(OrganizationService organization) {
        this.organization = organization;
    }
    
    
}
