/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Venture;


import Project.Role.BillingAdminRoleService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Accounting extends Venture {
    public Accounting(String name) {
    super(name, Venture.VentureType.Accounting);
}

@Override    
public ArrayList<RoleService> getSupportedRole() {
    role = new ArrayList<RoleService>();
    role.add(new BillingAdminRoleService());
   //  role.add(new PoliceHead());
    return role;
}
    
}
