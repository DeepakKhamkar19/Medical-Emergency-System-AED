/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Venture;

import Project.Role.BillingAdminRoleService;
import Project.Role.MedicineAdminService;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Medicine extends Venture{

    public Medicine(String name) {
        super(name,VentureType.MedicalUnit);
    }
    
    @Override    
    public ArrayList<RoleService> getSupportedRole() {
        role = new ArrayList<RoleService>();
        role.add(new MedicineAdminService());
       //  role.add(new PoliceHead());
        return role;
    }
    
}
