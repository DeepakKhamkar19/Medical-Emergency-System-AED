/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Venture;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class VentureDirectory {
     private ArrayList<Venture> ventureList;

    public VentureDirectory() {
        ventureList = new ArrayList();
    }

     
     
    public ArrayList<Venture> getVentureList() {
        return ventureList;
    }

    public void setVentureList(ArrayList<Venture> ventureList) {
        this.ventureList = ventureList;
    }
     
    
    public Venture createAndAddVenture(String name, Venture.VentureType type) {
        Venture venture = null;
        if (type == Venture.VentureType.EmergencyUnit) {
            venture = new Emergency(name);
            ventureList.add(venture);
        }
        
        else if (type == Venture.VentureType.Accounting) {
            venture = new Accounting(name);
            ventureList.add(venture);
        }
         
        else if (type == Venture.VentureType.EquipmentUnit) {
         venture = new Equipment(name);
         ventureList.add(venture);
        }
        
        else if (type == Venture.VentureType.ManagementUnit) {
            venture = new Management(name);
            ventureList.add(venture);
        }
        
         else if (type == Venture.VentureType.MedicalUnit) {
            venture = new Medicine(name);
            ventureList.add(venture);
        }
        
        
        
//        if (type == Venture.VentureType.Home) {
//            enterprise = new HomeEnterprise(name);
//            ventureList.add(enterprise);
//        }
//        if (type == Venture.VentureType.Government) {
//            enterprise = new GovernmentEnterprise(name);
//            ventureList.add(enterprise);
//        }

        return venture;
    }
     
}
