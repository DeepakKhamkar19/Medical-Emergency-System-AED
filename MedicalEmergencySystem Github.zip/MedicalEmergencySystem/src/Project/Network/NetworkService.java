
package Project.Network;
import Project.Venture.VentureDirectory;

/**
 *
 * @author Dell
 */
public class NetworkService {
     private String netName;

    private VentureDirectory ventureDirectory;
    //Adding variables in network service 

    public NetworkService()
    {
         ventureDirectory = new VentureDirectory();
         // cReating new object for venture directory 
    }
    //Adding Getters and setters 
    public String getNetName() {
        return netName;
    }

    public void setNetName(String netName) {
        this.netName = netName;
    }

    public VentureDirectory getVentureDirectory() {
        return ventureDirectory;
    }

    public void setVentureDirectory(VentureDirectory ventureDirectory) {
        this.ventureDirectory = ventureDirectory;
    }
    
     @Override
    public String toString() {
        return netName;
    }
      // Using the toString() method 
    // from the String class to change 
    //the variables to string 
    
}
