package Project;

import Project.Venture.Venture;
import Project.Equipment.EquipmentList;
import Project.MedicalEmployment.DoctorrList;
import Project.MedicalEmployment.PatienttList;
import Project.MedicalEmployment.AmbulanceeList;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import Project.Role.RoleService;
import Project.Role.SystemAdminRoleService;
import Project.UserAccount.UserAccountService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class EcoSystem extends OrganizationService{
    //Class ecosystem extending class OrganizationService 
    private static EcoSystem business;
    //creating an arraylist of typr Network service as networkList 
     private ArrayList<NetworkService> networkList;
     private PatienttList patientDirectory;
     private DoctorrList doctroDirectory;
     private AmbulanceeList ambulanceDirectory;
     private EquipmentList equipmentList;
     //Creating objects of each directory 

    public EcoSystem(String name) {
    }
    
    public static EcoSystem getInstance(){
        //If object of ecosystem is null it will create a new object of type ecosystem 
        if(business==null){
            business=new EcoSystem();
        }
        return business;
    }
    
    @Override
    public ArrayList<RoleService> getSupportedRole() {
        //Creating an object rolelist of type Role service using array list
        ArrayList<RoleService> roleList=new ArrayList<RoleService>();
        roleList.add(new SystemAdminRoleService());
        //returning the created object 
        return roleList;
    }
    
    private EcoSystem(){
        super(null);
        // Creating objects using network service array list using constructors of classes  
        networkList = new ArrayList<NetworkService>();
        patientDirectory = new PatienttList();
        doctroDirectory = new DoctorrList();
        ambulanceDirectory = new AmbulanceeList();
        equipmentList = new EquipmentList();

       
    }

    public NetworkService createAndAddNetwork() {
        //creating adding new network and then returninng the created network  
        NetworkService network = new NetworkService();
        networkList.add(network);
        return network;
    }
    
    public ArrayList<NetworkService> getNetworkList() {
        // returning networklist object 
        return networkList;
    }

    public void setNetworkList(ArrayList<NetworkService> networkList) {
        this.networkList = networkList;
    }

    
    public boolean checkIfUserIsUnique(String userName){
        // to check is user is unique each time 
         if (!this.getUserAccounttDirectory().checkIfUsernameIsUnique(userName)) {
            return false;
        }

        for (NetworkService network : this.getNetworkList()) {
            for (Venture enterprise : network.getVentureDirectory().getVentureList()) {
                for (UserAccountService ua : enterprise.getUserAccounttDirectory().getUserAccounttList()) {
                    if (ua.getUserName().equalsIgnoreCase(userName)) {
                        return false;
                    }
                }
                for (OrganizationService organization : enterprise.getOrganizationDirectory().getOrganizationList()) {
                    for (UserAccountService ua : organization.getUserAccounttDirectory().getUserAccounttList()) {
                        if (ua.getUserName().equalsIgnoreCase(userName)) {
                            return false;
                        }
                    }
                    //Cretaing method to check if the given user is unique or not 
                }
            }
        }

        return true;
    }
    
//    

    public static EcoSystem getBusiness() {
        return business;
    }

    public static void setBusiness(EcoSystem business) {
        EcoSystem.business = business;
    }

    public DoctorrList getDoctroDirectory() {
        return doctroDirectory;
    }

    public void setDoctroDirectory(DoctorrList doctroDirectory) {
        this.doctroDirectory = doctroDirectory;
    }

    public AmbulanceeList getAmbulanceDirectory() {
        return ambulanceDirectory;
    }

    public void setAmbulanceDirectory(AmbulanceeList ambulanceDirectory) {
        this.ambulanceDirectory = ambulanceDirectory;
    }

    public EquipmentList getEquipmentList() {
        return equipmentList;
    }

    public void setEquipmentList(EquipmentList equipmentList) {
        this.equipmentList = equipmentList;
    }



    public PatienttList getPatientDirectory() {
        return patientDirectory;
    }

    public void setPatientDirectory(PatienttList patientDirectory) {
        this.patientDirectory = patientDirectory;
    }
    
    
}
