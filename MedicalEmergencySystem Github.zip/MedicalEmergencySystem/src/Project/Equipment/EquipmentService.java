package Project.Equipment;

/**
 *
 * @author Dell
 */
public class EquipmentService {
    
    private String equiID;
    private String equiName;
    private String availableeQuant;
    private String desc;
    private double price;
    private double TotalPrice;
    int minimum = 100;
    int maximum = 999;
    //Decxkaring variables for Equipment Service

    public EquipmentService(String equiName, String description, String availableeQuant, double price, double totalPrice) {
        this.equiID = equiID;
        this.equiName = equiName;
        this.availableeQuant = availableeQuant;
        this.price = price;
        this.desc = description;
        this.TotalPrice = totalPrice;
        int randomNumber = (int)(Math.random() * (maximum - minimum + 1) + minimum);
        equiID= "EQ-"+randomNumber;
        //Assigning the created new varibles to class variables
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getEquiID() {
        return equiID;
    }

    public void setEquiID(String equiID) {
        this.equiID = equiID;
    }

    public String getEquiName() {
        return equiName;
    }

    public void setEquiName(String equiName) {
        this.equiName = equiName;
    }

    public String getAvailableeQuant() {
        return availableeQuant;
    }

    public void setAvailableeQuant(String availableeQuant) {
        this.availableeQuant = availableeQuant;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    @Override
    public String toString()
    {
        return this.equiName;
    }
    //Using to String method
    //of class String to convert objects in string format
    
    
}
