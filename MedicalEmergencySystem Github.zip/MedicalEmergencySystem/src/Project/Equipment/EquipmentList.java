package Project.Equipment;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class EquipmentList {
    private ArrayList<EquipmentService> equipmentList;
    // Cfreating array list of type equipment service named equipmentlist
    public EquipmentList() {
        this.equipmentList = new ArrayList();
        //Assigning this equipment list to a new array list 
    }
    
    public EquipmentService addNewEquip(String equipmetName, String Desc, String availableQuant, double cost,double totalcost)
    {
        //Creating a method to add new equipment 
        EquipmentService equipment = new EquipmentService(equipmetName, Desc, availableQuant, cost,totalcost);
        equipmentList.add(equipment);
        //retuning the new created equipment
        return equipment;
        
    }

    public ArrayList<EquipmentService> getEquipmentList() {
        return equipmentList;
    }

    public void setEquipmentList(ArrayList<EquipmentService> equipmentList) {
        this.equipmentList = equipmentList;
    }
    
    
}
