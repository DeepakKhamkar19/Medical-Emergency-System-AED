
package Project.Medicine;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class PrescriiptionnList {
      private ArrayList<PrescriptionService> prescriiptionList;
     //Creating an object of medicine service array list named medicine list
      
    public PrescriiptionnList(){
        prescriiptionList=new ArrayList<PrescriptionService>();
    }

    public ArrayList<PrescriptionService> getPrescriiptionList() {
        return prescriiptionList;
    }

    public void setPrescriiptionList(ArrayList<PrescriptionService> prescriiptionList) {
        this.prescriiptionList = prescriiptionList;
    }
   // public PrescriptionService addPrescriiption(PrescriptionS
    
    public PrescriptionService addPrescriiption(PrescriptionService prescriiption){

         prescriiptionList.add(prescriiption);
         return prescriiption;
         
         //prescriiptionList.add(prescriiption);
         //return prescriiption;
    }
}
