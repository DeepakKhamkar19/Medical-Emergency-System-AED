
package Project.Medicine;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class MedicineeList {
    
     private ArrayList<MedicineService> medicineeList;
     //Creating an object of medicine service array list named medicine list

    public MedicineeList() {
        medicineeList=new ArrayList<>();
        }

    public ArrayList<MedicineService> getMedicineeList() {
        return medicineeList;
    }

    public void setMedicineeList(ArrayList<MedicineService> medicineeList) {
        this.medicineeList = medicineeList;
    }
    
     public MedicineService addMedicinee()
    {
        MedicineService mi = new MedicineService();
        medicineeList.add(mi);
        return mi;
    }
    
    public void deleteeMedicine(MedicineService mi){
     medicineeList.remove(mi);
    }
}
