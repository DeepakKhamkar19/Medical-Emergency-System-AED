package Project.Medicine;

import java.util.Date;

/**
 *
 * @author Dell
 */
public class PrescriptionService {
     private int NumberOfTimesInaday;
    private int totallDays;
    private String daignosiss;
    private String medName;
    private Date prescDate;
    private String networkkName;
    //Adding Variables in Prescription service 
    
    
    //Adding Getters and Setters methods in the classes

    public String getNetworkkName() {
        return networkkName;
    }

    public void setNetworkkName(String networkkName) {
        this.networkkName = networkkName;
    }
    
    public Date getPrescDate() {
        return prescDate;
    }

    public void setPrescDate(Date prescDate) {
        this.prescDate = prescDate;
    }
   
    public String getMedName() {
        return medName;
    }

    public void setMedName(String medName) {
        this.medName = medName;
    }
   
    public String getDaignosiss() {
        return daignosiss;
    }

    public void setDaignosiss(String daignosiss) {
        this.daignosiss = daignosiss;
    }
   
    public int getNumberOfTimesInaday() {
        return NumberOfTimesInaday;
    }

    public void setNumberOfTimesInaday(int NumberOfTimesInaday) {
        this.NumberOfTimesInaday = NumberOfTimesInaday;
    }

    public int getTotallDays() {
        return totallDays;
    }

    public void setTotallDays(int totallDays) {
        this.totallDays = totallDays;
    }
      
}
