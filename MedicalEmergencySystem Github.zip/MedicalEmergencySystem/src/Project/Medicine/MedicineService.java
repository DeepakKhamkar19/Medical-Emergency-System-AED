
package Project.Medicine;

import java.util.Date;

/**
 *
 * @author Dell
 */
public class MedicineService {
    
    private String medName;
    private int reorderrLevel;
    private int minStock;
    private int maxStock;
    private Date expiryyDate;
    private String pharmaCategory;
    private int availQuant;
    private double purchaseePrice;
    private double sellinggPrice;
    private int producttId;
    private int seriallNumber;
    private int reqQuantity;
    private String reorderrStatus;
    //Declaring variables for class medicine service 
    
    //Creating the getter and setters methods for this class

    public String getMedName() {
        return medName;
    }

    public void setMedName(String medName) {
        this.medName = medName;
    }

    public int getReorderrLevel() {
        return reorderrLevel;
    }

    public void setReorderrLevel(int reorderrLevel) {
        this.reorderrLevel = reorderrLevel;
    }

    public int getMinStock() {
        return minStock;
    }

    public void setMinStock(int minStock) {
        this.minStock = minStock;
    }

    public int getMaxStock() {
        return maxStock;
    }

    public void setMaxStock(int maxStock) {
        this.maxStock = maxStock;
    }

    public Date getExpiryyDate() {
        return expiryyDate;
    }

    public void setExpiryyDate(Date expiryyDate) {
        this.expiryyDate = expiryyDate;
    }

    public String getPharmaCategory() {
        return pharmaCategory;
    }

    public void setPharmaCategory(String pharmaCategory) {
        this.pharmaCategory = pharmaCategory;
    }

    public int getAvailQuant() {
        return availQuant;
    }

    public void setAvailQuant(int availQuant) {
        this.availQuant = availQuant;
    }

    public double getPurchaseePrice() {
        return purchaseePrice;
    }

    public void setPurchaseePrice(double purchaseePrice) {
        this.purchaseePrice = purchaseePrice;
    }

    public double getSellinggPrice() {
        return sellinggPrice;
    }

    public void setSellinggPrice(double sellinggPrice) {
        this.sellinggPrice = sellinggPrice;
    }

    public int getProducttId() {
        return producttId;
    }

    public void setProducttId(int producttId) {
        this.producttId = producttId;
    }

    public int getSeriallNumber() {
        return seriallNumber;
    }

    public void setSeriallNumber(int seriallNumber) {
        this.seriallNumber = seriallNumber;
    }

    public int getReqQuantity() {
        return reqQuantity;
    }

    public void setReqQuantity(int reqQuantity) {
        this.reqQuantity = reqQuantity;
    }

    public String getReorderrStatus() {
        return reorderrStatus;
    }

    public void setReorderrStatus(String reorderrStatus) {
        this.reorderrStatus = reorderrStatus;
    }
    
     @Override
 public String toString(){
   return this.medName;
    }   
 
 
 // Using tostring() method of String class 
 // to convert an  object to string 
}
