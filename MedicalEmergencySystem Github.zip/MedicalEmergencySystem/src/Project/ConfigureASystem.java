package Project;

import Project.Employee.Employee;
import Project.Role.SystemAdminRoleService;
import Project.UserAccount.UserAccountService;

/**
 *
 * @author Dell
 */
public class ConfigureASystem {
    
    public static EcoSystem configure(){
        //Creating a ecosystem class object in the file 
        EcoSystem system = EcoSystem.getInstance();
        
        
        Employee employee = system.getEmployeeeDirectory().createEmployee("RRH");
        //Creating a user sccount 
        UserAccountService ua = system.getUserAccounttDirectory().createUserAccount("sysadmin", "sysadmin", employee, new SystemAdminRoleService());
        //returning the created system 
        return system;
    }
    
}
