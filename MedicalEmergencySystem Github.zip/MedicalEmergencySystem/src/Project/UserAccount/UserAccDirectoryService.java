/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.UserAccount;

import Project.Employee.Employee;
import Project.Role.RoleService;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class UserAccDirectoryService {
    
    private ArrayList<UserAccountService> userAccounttList;

    public UserAccDirectoryService() {
        userAccounttList = new ArrayList();
    }

    public ArrayList<UserAccountService> getUserAccounttList() {
        return userAccounttList;
    }
    
    public UserAccountService authenticateUser(String username, String password){
        for (UserAccountService uas : userAccounttList)
            if (uas.getUserName().equals(username) && uas.getPasswrd().equals(password)){
                return uas;
            }
        return null;
    }
    
    public UserAccountService createUserAccount(String userName, String passwrd, Employee employeee, RoleService rolee){
        UserAccountService userAccount = new UserAccountService();
        userAccount.setUserName(userName);
        userAccount.setPasswrd(passwrd);
        userAccount.setEmployeee(employeee);
        userAccount.setRolee(rolee);
        userAccounttList.add(userAccount);
        return userAccount;
    }
    
    public boolean checkIfUsernameIsUnique(String userName){
        for (UserAccountService uas : userAccounttList){
            if (uas.getUserName().equals(userName))
                return false;
        }
        return true;
    }
}
