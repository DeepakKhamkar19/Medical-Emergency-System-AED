/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.UserAccount;

import Project.Employee.Employee;
import Project.Role.RoleService;
import Project.WorkQueue.WorkkQueueService;

/**
 *
 * @author Dell
 */
public class UserAccountService {
    
    private String userName;
    private String passwrd;
    private Employee employeee;
    private RoleService rolee;
    private WorkkQueueService workkQueue;

    public UserAccountService() {
        workkQueue = new WorkkQueueService();
    }
    
    
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPasswrd() {
        return passwrd;
    }

    public void setPasswrd(String passwrd) {
        this.passwrd = passwrd;
    }

    public RoleService getRolee() {
        return rolee;
    }

    public void setEmployeee(Employee employeee) {
        this.employeee = employeee;
    }

    public void setRolee(RoleService rolee) {
        this.rolee = rolee;
    }

    public Employee getEmployeee() {
        return employeee;
    }

    public WorkkQueueService getWorkkQueue() {
        return workkQueue;
    }

    
    
    @Override
    public String toString() {
        return userName;
    }
    
    
    
}