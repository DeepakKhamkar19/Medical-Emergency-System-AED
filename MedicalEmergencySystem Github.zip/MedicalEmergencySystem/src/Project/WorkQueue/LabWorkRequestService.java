/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

import Project.MedicalEmployment.DoctorService;
import Project.MedicalEmployment.PatientDetails;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class LabWorkRequestService extends WorkRequestService {
    
    private OrganizationService senderOrg;
    private OrganizationService recieverOrg;
    private NetworkService senderNet;
    private NetworkService recieverNet;
    private String LabTestReqId;
    private PatientDetails pati;
    private DoctorService doc;
    private String speciType;
    private String patId;
    private String labTesttName;
    private String labTestAdmFeedbck;
    Date reqdate;
    Date ackDate;
    Date resolveDate;
    String stat;
    int minimum = 100;
    int maximum = 999;
    
    public LabWorkRequestService(){
        int randomNumber = (int)(Math.random() * (maximum - minimum + 1) + minimum);
        LabTestReqId= "LR"+randomNumber;
    }

    public OrganizationService getSenderOrg() {
        return senderOrg;
    }

    public void setSenderOrg(OrganizationService senderOrg) {
        this.senderOrg = senderOrg;
    }

    public OrganizationService getRecieverOrg() {
        return recieverOrg;
    }

    public void setRecieverOrg(OrganizationService recieverOrg) {
        this.recieverOrg = recieverOrg;
    }

    public NetworkService getSenderNet() {
        return senderNet;
    }

    public void setSenderNet(NetworkService senderNet) {
        this.senderNet = senderNet;
    }

    public NetworkService getRecieverNet() {
        return recieverNet;
    }

    public void setRecieverNet(NetworkService recieverNet) {
        this.recieverNet = recieverNet;
    }

    public String getLabTestReqId() {
        return LabTestReqId;
    }

    public void setLabTestReqId(String LabTestReqId) {
        this.LabTestReqId = LabTestReqId;
    }

    public PatientDetails getPati() {
        return pati;
    }

    public void setPati(PatientDetails pati) {
        this.pati = pati;
    }

    public DoctorService getDoc() {
        return doc;
    }

    public void setDoc(DoctorService doc) {
        this.doc = doc;
    }

    

    public String getSpeciType() {
        return speciType;
    }

    public void setSpeciType(String speciType) {
        this.speciType = speciType;
    }

    public String getPatId() {
        return patId;
    }

    public void setPatId(String patId) {
        this.patId = patId;
    }

    public String getLabTesttName() {
        return labTesttName;
    }

    public void setLabTesttName(String labTesttName) {
        this.labTesttName = labTesttName;
    }

    public String getLabTestAdmFeedbck() {
        return labTestAdmFeedbck;
    }

    public void setLabTestAdmFeedbck(String labTestAdmFeedbck) {
        this.labTestAdmFeedbck = labTestAdmFeedbck;
    }

    public Date getReqdate() {
        return reqdate;
    }

    public void setReqdate(Date reqdate) {
        this.reqdate = reqdate;
    }

    public Date getAckDate() {
        return ackDate;
    }

    public void setAckDate(Date ackDate) {
        this.ackDate = ackDate;
    }

    public Date getResolvDate() {
        return resolveDate;
    }

    public void setResolvDate(Date resolveDate) {
        this.resolveDate = resolveDate;
    }

    public String getStat() {
        return stat;
    }

    public void setStat(String status) {
        this.stat = status;
    }
    
    @Override
    public String toString() {
        return LabTestReqId;
    }
}
