/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class EquipmentWorkRequestService {
    private OrganizationService senderOrg;
    private OrganizationService recieverOrg;
    private NetworkService senderNet;
    private NetworkService recieverNet;
    private String EquipmentReqId;
    private String EquiId;
    private String EquiName;
    private String Reasonn;
    private int numberOfUnits;
    private double equiPrice;
    private String stat;
    Date reqdate;
    Date ackDate;
    Date resDate;
    int minimum = 100;
    int maximum = 999;
    
    
    public EquipmentWorkRequestService() {
        int randomNum = (int)(Math.random() * (maximum - minimum + 1) + minimum);
        EquipmentReqId= "EP"+randomNum;  
    }

    public OrganizationService getSenderOrg() {
        return senderOrg;
    }

    public void setSenderOrg(OrganizationService senderOrg) {
        this.senderOrg = senderOrg;
    }

    public OrganizationService getRecieverOrg() {
        return recieverOrg;
    }

    public void setRecieverOrg(OrganizationService recieverOrg) {
        this.recieverOrg = recieverOrg;
    }

    public NetworkService getSenderNet() {
        return senderNet;
    }

    public void setSenderNet(NetworkService senderNet) {
        this.senderNet = senderNet;
    }

    public NetworkService getRecieverNet() {
        return recieverNet;
    }

    public void setRecieverNet(NetworkService recieverNet) {
        this.recieverNet = recieverNet;
    }

    public String getEquipmentReqId() {
        return EquipmentReqId;
    }

    public void setEquipmentReqId(String EquipmentReqId) {
        this.EquipmentReqId = EquipmentReqId;
    }

    public String getEquiId() {
        return EquiId;
    }

    public void setEquiId(String EquiId) {
        this.EquiId = EquiId;
    }

    public String getEquiName() {
        return EquiName;
    }

    public void setEquiName(String EquiName) {
        this.EquiName = EquiName;
    }

    public String getReasonn() {
        return Reasonn;
    }

    public void setReasonn(String Reasonn) {
        this.Reasonn = Reasonn;
    }

    public int getNumberOfUnits() {
        return numberOfUnits;
    }

    public void setNumberOfUnits(int numberOfUnits) {
        this.numberOfUnits = numberOfUnits;
    }

    public double getEquiPrice() {
        return equiPrice;
    }

    public void setEquiPrice(double equiPrice) {
        this.equiPrice = equiPrice;
    }

    public String getStat() {
        return stat;
    }

    public void setStat(String stat) {
        this.stat = stat;
    }

    public Date getReqdate() {
        return reqdate;
    }

    public void setReqdate(Date reqdate) {
        this.reqdate = reqdate;
    }

    public Date getAckDate() {
        return ackDate;
    }

    public void setAckDate(Date ackDate) {
        this.ackDate = ackDate;
    }
    
    @Override
    public String toString() {
        return EquipmentReqId;
    }
    
    
}
