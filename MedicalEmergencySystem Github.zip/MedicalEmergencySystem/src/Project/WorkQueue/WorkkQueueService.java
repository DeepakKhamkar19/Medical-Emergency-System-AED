/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class WorkkQueueService {
    
    private ArrayList<WorkRequestService> workRequestList;

    public WorkkQueueService() {
        workRequestList = new ArrayList();
    }

    public ArrayList<WorkRequestService> getWorkRequestList() {
        return workRequestList;
    }
    
    public void addWorkRequest(WorkRequestService workReq)
    {
        workRequestList.add(workReq);
    }
}