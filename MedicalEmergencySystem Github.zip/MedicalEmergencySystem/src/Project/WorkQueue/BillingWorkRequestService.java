 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

import Project.Equipment.EquipmentService;
import Project.MedicalEmployment.DoctorService;
import Project.MedicalEmployment.PatientDetails;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class BillingWorkRequestService extends WorkRequestService {
    
    
    private OrganizationService senderOrg;
    private OrganizationService recieverOrg;
    private NetworkService senderNet;
    private NetworkService recieverNet;
    private String billingReqId;
    private String EquiId;
    private String EquiName;
    private int numberOfUnits;
    private double fundAvailable;
    private double equiPrice;
    private double totalEquiCost;
    private EquipmentService equi;
    private double fundsAllocated;
    private String stat;
    Date requestDate;
    Date ackDate;
    Date resDate;
    String Stat ;
    int min = 100;
    int max = 999;

    public BillingWorkRequestService () {
        int randomNum = (int)(Math.random() * (max - min + 1) + min);
        billingReqId= "BR"+randomNum;
        
    }

    public EquipmentService getEqui() {
        return equi;
    }

    public void setEqui(EquipmentService equi) {
        this.equi = equi;
    }

    public String getBillingReqId() {
        return billingReqId;
    }

    public String getEquiId() {
        return EquiId;
    }

    public void setEquiId(String EquiId) {
        this.EquiId = EquiId;
    }

    public void setBillingReqId(String billingReqId) {
        this.billingReqId = billingReqId;
    }

    public double getFundsAllocated() {
        return fundsAllocated;
    }

    public void setFundsAllocated(double fundsAllocated) {
        this.fundsAllocated = fundsAllocated;
    }
    
   
    public Date getReqDate() {
        return requestDate;
    }

    public void setReqDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getAckDate() {
        return ackDate;
    }

    public void setAckDate(Date ackDate) {
        this.ackDate = ackDate;
    }

    public Date getResolvDate() {
        return resDate;
    }

    public void setResolvDate(Date resolveDate) {
        this.resDate = resolveDate;
    }

    public String getStat() {
        return Stat;
    }

    public void setStat(String Status) {
        this.Stat = Status;
    }

    public OrganizationService getSenderOrg() {
        return senderOrg;
    }

    public void setSenderOrg(OrganizationService senderOrg) {
        this.senderOrg = senderOrg;
    }

    public OrganizationService getRecieverOrg() {
        return recieverOrg;
    }

    public void setRecieverOrg(OrganizationService recieverOrg) {
        this.recieverOrg = recieverOrg;
    }

    public NetworkService getSenderNet() {
        return senderNet;
    }

    public void setSenderNet(NetworkService senderNet) {
        this.senderNet = senderNet;
    }

    public NetworkService getRecieverNet() {
        return recieverNet;
    }

    public void setRecieverNet(NetworkService recieverNet) {
        this.recieverNet = recieverNet;
    }

    public String getEquiName() {
        return EquiName;
    }

    public void setEquiName(String EquiName) {
        this.EquiName = EquiName;
    }

    public int getNumberOfUnits() {
        return numberOfUnits;
    }

    public void setNumberOfUnits(int numberOfUnits) {
        this.numberOfUnits = numberOfUnits;
    }

    public double getFundAvailable() {
        return fundAvailable;
    }

    public void setFundAvailable(double fundAvailable) {
        this.fundAvailable = fundAvailable;
    }

    public double getEquiPrice() {
        return equiPrice;
    }

    public void setEquiPrice(double equiPrice) {
        this.equiPrice = equiPrice;
    }

    public double getTotalEquiCost() {
        return totalEquiCost;
    }

    public void setTotalEquiCost(double totalEquiCost) {
        this.totalEquiCost = totalEquiCost;
    }
    
    
    @Override
    public String toString() {
        return billingReqId;
    }
    
    
}
