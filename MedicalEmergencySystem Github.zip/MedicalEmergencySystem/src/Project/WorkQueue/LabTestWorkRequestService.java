/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

/**
 *
 * @author Dell
 */
public class LabTestWorkRequestService extends WorkRequestService{
    
    private String testRes;

    public String getTestRes() {
        return testRes;
    }

    public void setTestRes(String testRes) {
        this.testRes = testRes;
    }
    
    
}
