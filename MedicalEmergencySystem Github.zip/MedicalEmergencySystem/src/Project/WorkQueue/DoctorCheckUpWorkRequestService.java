/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

import Project.MedicalEmployment.DoctorService;
import Project.MedicalEmployment.PatientDetails;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import Project.VitalSigns.VitalSignsService;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class DoctorCheckUpWorkRequestService extends WorkRequestService {
    private VitalSignsService checkkUp;
    private OrganizationService senderrOrganization;
    private OrganizationService recieverrOrganization;
    private NetworkService senderrNetwork;
    private NetworkService recieverrNetwork;
    private PatientDetails pat  ;
    private DoctorService doc;
    Date requestDate;
    Date ackDate;
    Date resDate;
    String Stat ;
    String checkupReqId ;
    int minimum = 100;
    int maximum = 999;

    public DoctorCheckUpWorkRequestService() {
        checkkUp = new VitalSignsService();
        int randomNum = (int)(Math.random() * (maximum - minimum + 1) + minimum);
        checkupReqId= "CHK"+randomNum;
    }

    public String getCheckupReqId() {
        return checkupReqId;
    }

    public void setCheckupReqId(String checkupReqId) {
        this.checkupReqId = checkupReqId;
    }

    
    public DoctorService getDoc() {
        return doc;
    }

    public void setDoc(DoctorService doc) {
        this.doc = doc;
    }

    
    public VitalSignsService getCheckkUp() {
        return checkkUp;
    }

    public void setCheckkUp(VitalSignsService checkkUp) {
        this.checkkUp = checkkUp;
    }

    public OrganizationService getSenderrOrganization() {
        return senderrOrganization;
    }

    public void setSenderrOrganization(OrganizationService senderrOrganization) {
        this.senderrOrganization = senderrOrganization;
    }

    public OrganizationService getRecieverrOrganization() {
        return recieverrOrganization;
    }

    public void setRecieverrOrganization(OrganizationService recieverrOrganization) {
        this.recieverrOrganization = recieverrOrganization;
    }

    public NetworkService getSenderrNetwork() {
        return senderrNetwork;
    }

    public void setSenderrNetwork(NetworkService senderrNetwork) {
        this.senderrNetwork = senderrNetwork;
    }

    public NetworkService getRecieverrNetwork() {
        return recieverrNetwork;
    }

    public void setRecieverrNetwork(NetworkService recieverrNetwork) {
        this.recieverrNetwork = recieverrNetwork;
    }

    public PatientDetails getPat() {
        return pat;
    }

    public void setPat(PatientDetails pat) {
        this.pat = pat;
    }

    public Date getReqDate() {
        return requestDate;
    }

    public void setReqDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getAckDate() {
        return ackDate;
    }

    public void setAckDate(Date ackDate) {
        this.ackDate = ackDate;
    }

    public Date getResolvDate() {
        return resDate;
    }

    public void setResolvDate(Date resolveDate) {
        this.resDate = resolveDate;
    }

    public String getStat() {
        return Stat;
    }

    public void setStat(String Status) {
        this.Stat = Status;
    }
    
    
}
