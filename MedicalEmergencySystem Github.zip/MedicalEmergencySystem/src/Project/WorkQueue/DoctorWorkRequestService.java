/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

import Project.MedicalEmployment.DoctorService;
import Project.MedicalEmployment.PatientDetails;
import Project.Network.NetworkService;
import Project.Organization.OrganizationService;
import java.util.Date;

/**
 *
 * @author Dell
 */
public class DoctorWorkRequestService extends WorkRequestService {
    
    
    private OrganizationService senderOrg;
    private OrganizationService recieverOrg;
    private NetworkService senderNet;
    private NetworkService recieverNet;
    private PatientDetails pat  ;
    private String critical; //MEdium . low . High
    DoctorService EmerDoctor ;
    DoctorService  patientPrevDoctor ;
    String emergencyReqId ;
    EmergencyPatientRequestService emergencyPatRequest;
    Date requestDate;
    Date ackDate;
    Date resDate;
    String Stat ;
    int minimum = 100;
    int maximum = 999;

    public DoctorWorkRequestService() {
        int randomNum = (int)(Math.random() * (maximum - minimum + 1) + minimum);
        emergencyReqId= "DR"+randomNum;
        
    }

    public EmergencyPatientRequestService getEmergencyPatRequest() {
        return emergencyPatRequest;
    }

    public void setEmergencyPatRequest(EmergencyPatientRequestService emergencyPatRequest) {
        this.emergencyPatRequest = emergencyPatRequest;
    }
    
    
    
    public PatientDetails getPat() {
        return pat;
    }

    public void setPat(PatientDetails pat) {
        this.pat = pat;
    }

    public String getCritical() {
        return critical;
    }

    public void setCritical(String critical) {
        this.critical = critical;
    }



    public DoctorService getEmerDoctor() {
        return EmerDoctor;
    }

    public void setEmerDoctor(DoctorService EmerDoctor) {
        this.EmerDoctor = EmerDoctor;
    }

    public DoctorService getPatientPrevDoctor() {
        return patientPrevDoctor;
    }

    public void setPatientPrevDoctor(DoctorService patientPrevDoctor) {
        this.patientPrevDoctor = patientPrevDoctor;
    }

    public String getEmergencyReqId() {
        return emergencyReqId;
    }

    public void setEmergencyReqId(String emergencyReqId) {
        this.emergencyReqId = emergencyReqId;
    }

   
    public Date getReqDate() {
        return requestDate;
    }

    public void setReqDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public Date getAckDate() {
        return ackDate;
    }

    public void setAckDate(Date ackDate) {
        this.ackDate = ackDate;
    }

    public Date getResolvDate() {
        return resDate;
    }

    public void setResolvDate(Date resolveDate) {
        this.resDate = resolveDate;
    }

    public String getStat() {
        return Stat;
    }

    public void setStat(String Status) {
        this.Stat = Status;
    }

    public OrganizationService getSenderOrg() {
        return senderOrg;
    }

    public void setSenderOrg(OrganizationService senderOrg) {
        this.senderOrg = senderOrg;
    }

    public OrganizationService getRecieverOrg() {
        return recieverOrg;
    }

    public void setRecieverOrg(OrganizationService recieverOrg) {
        this.recieverOrg = recieverOrg;
    }

    public NetworkService getSenderNet() {
        return senderNet;
    }

    public void setSenderNet(NetworkService senderNet) {
        this.senderNet = senderNet;
    }

    public NetworkService getRecieverNet() {
        return recieverNet;
    }

    public void setRecieverNet(NetworkService recieverNet) {
        this.recieverNet = recieverNet;
    }
    
    
    @Override
    public String toString() {
        return emergencyReqId;
    }
    
    
}
