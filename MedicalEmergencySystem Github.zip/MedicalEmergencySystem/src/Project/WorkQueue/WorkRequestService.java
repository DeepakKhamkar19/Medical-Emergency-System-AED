/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.WorkQueue;

//import Business.Customer.Customer;
//import Business.DeliveryMan.DeliveryMan;
//import Business.Restaurant.Restaurant;
import Project.UserAccount.UserAccountService;
import java.util.Date;

/**
 *
 * @author Dell
 */
public abstract class WorkRequestService {

    private String mes;
    private UserAccountService sendr;
    private UserAccountService receivr;
    private String stat;
    private Date reqDate;
    private Date resDate;
 
   
   

    
    
    public WorkRequestService(){
        reqDate = new Date();
    }

   
    
    

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public UserAccountService getSendr() {
        return sendr;
    }

    public void setSendr(UserAccountService sendr) {
        this.sendr = sendr;
    }

    public UserAccountService getReceivr() {
        return receivr;
    }

    public void setReceivr(UserAccountService receivr) {
        this.receivr = receivr;
    }

    public String getStat() {
        return stat;
    }

    public void setStat(String status) {
        this.stat = status;
    }

    public Date getReqDate() {
        return reqDate;
    }

    public void setReqDate(Date reqDate) {
        this.reqDate = reqDate;
    }

    public Date getResolvDate() {
        return resDate;
    }

    public void setResolvDate(Date resolveDate) {
        this.resDate = resolveDate;
    }

  
    
    
    
    @Override
    public String toString()
    {
        return sendr.getEmployeee().getName();
    }
}
