/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Billing;

/**
 *
 * @author Raveena
 */
public class Billing {
 
    private String userName;
    private String patientName;
    private String admitDate;
    private String dischargeDate;
    private String totalAmount;

      public Billing(String userName, String patientName, String admitDate, String dischargeDate,String totalAmount) {  
        this.userName = userName;
        this.patientName = patientName;
        this.admitDate = admitDate;
        this.dischargeDate = dischargeDate;
        this.totalAmount = totalAmount;
      }
      
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getAdmitDate() {
        return admitDate;
    }

    public void setAdmitDate(String admitDate) {
        this.admitDate = admitDate;
    }

    public String getDischargeDate() {
        return dischargeDate;
    }

    public void setDischargeDate(String dischargeDate) {
        this.dischargeDate = dischargeDate;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    @Override
    public String toString() {
        return userName;
    }
   
  
}
