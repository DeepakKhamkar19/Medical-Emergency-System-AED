/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Billing;

import java.util.ArrayList;

public class BillingDirectory {
    
    private ArrayList<Billing> billingDirectory;
    
    public BillingDirectory() {
        
        billingDirectory = new ArrayList();
        
    }

    public ArrayList<Billing> getBillingDirectory() {
        return billingDirectory;
    }

    public void setBillingDirectory(ArrayList<Billing> billingDirectory) {
        this.billingDirectory = billingDirectory;
    }
    
    public Billing newBilling(String userName, String patientName, String admitDate, String dischargeDate,String totalAmount){
        Billing billing = new Billing(userName, patientName, admitDate, dischargeDate,totalAmount);
        billingDirectory.add(billing);
        return billing;
    }
    
    public void removeBilling(Billing billing){
        billingDirectory.remove(billing);
    }
    
    public Billing getBilling(String name){
        for(Billing billing: billingDirectory){
            if(billing.getPatientName().equalsIgnoreCase(name)){
                return billing;
            }
        }
        return null;
    }
    
}
