/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.EmergencyService;

/**
 *
 * @author Raveena
 */
public class EmergencyService {
    
    private String userName;
    private String patientName;

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
    private String vehicleNumber;
    private String emergencyAddress;
    private String Status;
    
    public EmergencyService (String userName, String patientName, String vehicleNumber, String emergencyAddress, String Status) {  
         
        this.userName = userName;
        this.patientName = patientName;
        this.vehicleNumber = vehicleNumber;
        this.emergencyAddress = emergencyAddress;
        this.Status = Status;
     
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getEmergencyAddress() {
        return emergencyAddress;
    }

    public void setEmergencyAddress(String emergencyAddress) {
        this.emergencyAddress = emergencyAddress;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }
    
    @Override
    public String toString() {
        return userName;
    }
  
}
