/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.EmergencyService;

import java.util.ArrayList;


public class EmergencyServiceDirectory{
    
    private ArrayList<EmergencyService> emergencyserviceDirectory;
    
    public EmergencyServiceDirectory() {
        
        emergencyserviceDirectory = new ArrayList();
       
    }

    public ArrayList<EmergencyService> getemergencyserviceDirectory() {
        return emergencyserviceDirectory;
    }

    public void setEmergencyServiceDirectory(ArrayList<EmergencyService> emergencyserviceDirectory) {
        this.emergencyserviceDirectory = emergencyserviceDirectory;
    }
    
    public EmergencyService newEmergencyService(String userName, String patientName, String vehicleNumber, String emergencyAddress, String Status){
        EmergencyService emergencyservice = new EmergencyService(userName, patientName, vehicleNumber, emergencyAddress, Status);
        emergencyserviceDirectory.add(emergencyservice);
        return emergencyservice;
    }
    
    public void removeEmergencyService(EmergencyService emergencyservice){
        emergencyserviceDirectory.remove(emergencyservice);
    }
    
    public EmergencyService getEmergencyService(String name){
        for(EmergencyService emergencyservice: emergencyserviceDirectory){
            if(emergencyservice.getPatientName().equalsIgnoreCase(name)){
                return emergencyservice;
            }
        }
        return null;
    }
    
}
