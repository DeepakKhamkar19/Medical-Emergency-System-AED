/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Laboratory;

import java.util.ArrayList;


public class LaboratoryDirectory{
    
    private ArrayList<Laboratory> laboratoryDirectory;
    
    public LaboratoryDirectory() {
        
        laboratoryDirectory = new ArrayList();
        
    }

    public ArrayList<Laboratory> getLaboratoryDirectory() {
        return laboratoryDirectory;
    }

    public void setLaboratoryDirectory(ArrayList<Laboratory> laboratoryDirectory) {
        this.laboratoryDirectory = laboratoryDirectory;
    }
    
    public Laboratory newLaboratory(String userName, String name, String address, String phoneNumber,String email, String patientName, String status){
        Laboratory laboratory = new Laboratory(userName, name, address, phoneNumber,email, patientName,status);
        laboratoryDirectory.add(laboratory);
        return laboratory;
    }
    
    public void removeLaboratory(Laboratory laboratory){
        laboratoryDirectory.remove(laboratory);
    }
    
    public Laboratory getLaboratory(String name){
        for(Laboratory laboratory: laboratoryDirectory){
            if(laboratory.getPatientName().equalsIgnoreCase(name)){
                return laboratory;
            }
        }
        return null;
    }
    
}

