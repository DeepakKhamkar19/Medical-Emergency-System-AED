/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Pharmacy;

/**
 *
 * @author Raveena
 */
public class Pharmacy {

    private String userName;
    private String patientName;
    private String address;
    private String medicines;
    private String totalAmount;
    private String status;

    public Pharmacy(String userName, String address, String medicines, String totalAmount,String status, String patientName) {  
        this.userName = userName;
        
        this.address = address;
        this.medicines = medicines;
        this.totalAmount = totalAmount;
        this.status = status;   
        this.patientName = patientName;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getMedicines() {
        return medicines;
    }

    public void setMedicines(String medicines) {
        this.medicines = medicines;
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    @Override
    public String toString() {
        return userName;
    }
     
}
