/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project.Pharmacy;

import java.util.ArrayList;


public class PharmacyDirectory {
    
    private ArrayList<Pharmacy> pharmacyDirectory;
    
    public PharmacyDirectory() {
        
        pharmacyDirectory = new ArrayList();
        
    }

    public ArrayList<Pharmacy> getPharmacyDirectory() {
        return pharmacyDirectory;
    }

    public void setPharmacyDirectory(ArrayList<Pharmacy> pharmacyDirectory) {
        this.pharmacyDirectory = pharmacyDirectory;
    }
    
    public Pharmacy newPharmacy(String userName, String patientName, String address, String medicines, String totalAmount,String status){
        Pharmacy pharmacy = new Pharmacy(userName,patientName,address,medicines,totalAmount,status);
        pharmacyDirectory.add(pharmacy);
        return pharmacy;
    }
    
    public void removePharmacy(Pharmacy pharmacy){
        pharmacyDirectory.remove(pharmacy);
    }
    
    public Pharmacy getPharmacy(String name){
        for(Pharmacy pharmacy: pharmacyDirectory){
            if(pharmacy.getPatientName().equalsIgnoreCase(name)){
                return pharmacy;
            }
        }
        return null;
    }
    
}
